# SE1-Project
Team: Adam G., Adam S., Sam W.

Team name: Project 2: Electric Googleoo

Objective: Randomizes people into teams from a csv file
