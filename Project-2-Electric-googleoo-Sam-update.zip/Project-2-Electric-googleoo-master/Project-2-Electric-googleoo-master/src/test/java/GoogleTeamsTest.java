/******************************************
 * Team Name: Project 2 Electric Googleoo
 * Authors: Adam Garcia, Adam Saxton, Sam Web
 * Class: Spring 2020 Dr,Reeves CS 3preference4 SE
 * Task: Tests GoogleTeams.java
 * Due Date: ¯\_(ツ)_/¯
 *
 */

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Rule;
import org.junit.runner.Description;
import org.junit.rules.TestRule;
import org.junit.rules.TestWatcher;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class GoogleTeamsTest
{

    GoogleTeams googleTeams;
    

    @Rule
    public TestRule watcher =
    	new TestWatcher() {
    	    protected void starting(Description description) {
    		System.out.println("Starting test: " + description.getMethodName());
    	}
    };
    
    @Before
    public void initialize() {
		googleTeams = new GoogleTeams();
    }


    @Test
    public void test1ReadFile()
    {
        boolean worked = googleTeams.readFile("Test.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test1matrixTest()
    {
        ArrayList<String> matrixTest = new ArrayList<String>();

        matrixTest.add("adam, sam, adam2");
        matrixTest.add("sam, adam, adam2");
        matrixTest.add("adam2, sam, adam");

        int [][] matrix = googleTeams.createMatrix(matrixTest);
        int [][] realMatrix = {{0,1,0},{1,0,1},{1,1,0}};

        //assertEquals(realMatrix, matrix);
        for(int i = 0; i < realMatrix.length; i++)
        {
            for(int j = 0; j < realMatrix[i].length; j++)
            {
                assertEquals(realMatrix[i][j], matrix[i][j]);
            }
        }

    }

    @Test
    public void test1point5ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase1_Nar.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test2ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase2_CAH.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test3ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase3_DP.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test4ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase4_Bio.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test5ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase5_HP.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test6ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase6_Blank.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test7ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase7_GG_Num.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test8ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase8_FMA.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test9ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase9_MCU.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test10ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase10_MASH.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test11ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase11_UT.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test12ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase12_OHSHC.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test13ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase13_MHA.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test14ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase14_SW.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test15ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase15_CH.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test16ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase16_AC.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test17ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase17_PMK.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test18ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase18_SM.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test19ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase19_BM.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test20ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase20_ATLA.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test21ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase21_Port.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test22ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase22_GF.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test23ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase23_OPM.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test24ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase24_LOTR.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test25ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase25_BATIM.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test26ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase26_MNT.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test27ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase27_LCITS.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test28ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase28_SA.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test29ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase29_HMC.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }

    @Test
    public void test30ReadFile()
    {
    	boolean worked = googleTeams.readFile("testcase30_PM.csv");
       	assertEquals(true,worked);
        System.out.println("\n");
    }
}